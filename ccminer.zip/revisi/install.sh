#!/bin/bash

# Warna hijau tebal
GREEN_BOLD="\e[1;32m"
CYAN_BOLD="\e[1;36;44m"
RESET="\e[0m"

# Spinner hijau di baris yang sama
spinner() {
    local pid=$!
    local delay=0.1
    local spinstr='🌑🌘🌗🌖🌕🌔🌓🌒'
    local i=0

    tput civis  # Sembunyikan kursor
    while kill -0 $pid 2>/dev/null; do
        local char="${spinstr:i++%${#spinstr}:1}"
        printf "\r${GREEN_BOLD}[%s] %s...${RESET}" "$char" "$CURRENT_MSG"
        sleep $delay
    done
    tput cnorm  # Tampilkan kembali kursor
    printf "\r${GREEN_BOLD}[🟢] %s... ✅${RESET}\n" "$CURRENT_MSG"
}

# Fungsi jalankan perintah dengan spinner dan sembunyikan output
run_cmd() {
    CURRENT_MSG="$1"
    bash -c "$2" > /dev/null 2>&1 & spinner
}


# Jalankan perintah-perintah
clear
echo -e "${CYAN_BOLD}================================${RESET}"
echo -e "${CYAN_BOLD}=    CCminer installer v0.1    =${RESET}"
echo -e "${CYAN_BOLD}================================${RESET}"
echo -e "${CYAN_BOLD}       Oleh Ari Kusnanto        ${RESET}"
run_cmd "Updating & Upgrading system" "apt update && apt upgrade -y -o Dpkg::Options::='--force-confold'"
run_cmd "Install Unzip" "apt install unzip -y -o Dpkg::Options::='--force-confold'"
run_cmd "Install Wget" "apt install wget -y -o Dpkg::Options::='--force-confold'"
run_cmd "Download File Build" "wget -O ccminer.zip https://github.com/zaxinaga/exava/raw/refs/heads/main/ccminer.zip"
run_cmd "Make Folder" "mkdir ccminer"
run_cmd "Unzip Ccminer" "unzip ccminer.zip -d ccminer"
run_cmd "Install Proot Distro" "pkg install proot-distro -y -o Dpkg::Options::='--force-confold'"
run_cmd "Check Available proot-distro" "proot-distro list"
run_cmd "Install Ubuntu" "proot-distro install ubuntu"
echo -e "${GREEN_BOLD}====Menyalin konfigurasi====${RESET}"
run_cmd "Copy Componen 1" "cp ~/ccminer/ubuntu.sh $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/ >> '$LOGFILE' 2>&1${RESET}"
run_cmd "Copy Componen 2" "cp ~/ccminer/ccminer.cpp $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/ >> '$LOGFILE' 2>&1${RESET}"
run_cmd "Copy Componen 1" "cp ~/ccminer/run.sh $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/ >> '$LOGFILE' 2>&1${RESET}"
run_cmd "Copy Componen 1" "cp ~/ccminer/ccminer.conf $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/ >> '$LOGFILE' 2>&1${RESET}"
echo -e "${GREEN_BOLD}====Done====${RESET}"
sleep 2
clear
echo -e "${CYAN_BOLD}================================${RESET}"
echo -e "${CYAN_BOLD}=    CCminer installer v0.1    =${RESET}"
echo -e "${CYAN_BOLD}================================${RESET}"
echo -e "${CYAN_BOLD}       Oleh Ari Kusnanto        ${RESET}"
echo -e "${GREEN_BOLD}Melanjutkan Proses di Ubuntu${RESET}"
proot-distro login ubuntu -- bash -c "chmod +x ubuntu.sh && bash ubuntu.sh"
