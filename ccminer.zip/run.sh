#!/data/data/com.termux/files/usr/bin/bash

CONFIG_FILE=".ccminer_save.conf"

# Bersihkan terminal dan hapus file sampah
clear
rm -f /root/ubuntu.sh /root/ccminer.cpp /root/ccminer.conf /root/run.sh
clear

# ===== MUAT KONFIGURASI SEBELUMNYA JIKA ADA =====
if [[ -f $CONFIG_FILE ]]; then
    source "$CONFIG_FILE"
fi

# ===== FORM INPUT =====
echo -e "\033[1;32m===== KONFIGURASI MINER =====\033[0m"

echo -e "\033[38;5;245m(default: ${pool:-stratum+tcp://sg.vipor.net:5040})\033[0m"
read -p "Pool   : " input_pool

echo -e "\033[38;5;245m(default: ${wallet:-RAv2drFAAu1qngCC2Sd89KQWk2VAa8dZkN.exava01})\033[0m"
read -p "Wallet : " input_wallet

echo -e "\033[38;5;245m(default: ${core:-4})\033[0m"
read -p "Core   : " input_core

# Gunakan input jika ada, jika tidak pakai yang lama atau default
pool=${input_pool:-${pool:-stratum+tcp://sg.vipor.net:5040}}
wallet=${input_wallet:-${wallet:-RAv2drFAAu1qngCC2Sd89KQWk2VAa8dZkN.exava01}}
core=${input_core:-${core:-4}}

# ===== SIMPAN KE FILE KONFIGURASI =====
cat <<EOF > "$CONFIG_FILE"
pool="$pool"
wallet="$wallet"
core="$core"
EOF

# Tampilkan konfigurasi akhir
echo -e "\n\033[1;34mMenggunakan Konfigurasi:\033[0m"
echo -e "Pool   : $pool"
echo -e "Wallet : $wallet"
echo -e "Core   : $core"
echo -e "\033[1;32mTombol CTRL+C untuk keluar, lalu ketik ./run.sh untuk Edit Kembali. Happy Mining!\033[0m"
sleep 3

# Buat pipe sementara
PIPE=$(mktemp -u)
mkfifo "$PIPE"

# === Tangani interupsi (CTRL+C) ===
cleanup() {
    echo -e "\n\033[1;31m[!] Dihentikan oleh pengguna. Membersihkan...\033[0m"
    kill $CCMINER_PID $SPINNER_PID $MONITOR_PID 2>/dev/null
    rm -f "$PIPE"
    tput cnorm
    clear
    exit 1
}
trap cleanup SIGINT

# Jalankan ccminer
./ccminer -a verus -o "$pool" -u "$wallet" -p d=4 -t "$core" \
  > "$PIPE" 2>&1 &

CCMINER_PID=$!

# Spinner function
spinner() {
    local pid=$1
    local frames=(
        "Mining[⠏|[◐"
        "mIning[⠇|][◓"
        "miNing[⠧|| ]---[◑"
        "minIng[⠦|| | ]-----[◒"
        "miniNg[⠴|| | | ]------[◐"
        "mininG[⠼|| | | | ]-------[◓"
        "Mining[⠹| | | | | | ]---------[◑"
        "mIning[⠙| | | | | | | ]-----------[◒"
        "miNing[⠋| | | | | | ]----------[◑"
        "minIng[⠏| | | | | ]---------[◓"
        "miniNg[⠇| | | | ]--------[◐"
        "mininG[⠧| | | ]-------[◒"
        "Mining[⠦|| | ]-----[◑"
        "mIning[⠴|| ]----[◓"
        "miNing[⠼|]---[◐"
        "minIng[⠹|]--[◒"
        "miniNg[⠙|]-[◑"
        "mininG[⠋|][◓"
    )
    local i=0
    tput civis

    while kill -0 $pid 2>/dev/null; do
        local frame="${frames[i]}"
        tput cup 0 0
        printf "\033[1;32m¿\033[0m\033[1;32m%s\033[0m\033[K" "$frame"
        sleep 0.1
        ((i = (i + 1) % ${#frames[@]}))
    done

    tput cnorm
}

# Monitor output ccminer
monitor_output() {
    local row=2
    while IFS= read -r line; do
        if [[ "$line" =~ [0-9]{4}-[0-9]{2}-[0-9]{2}\ [0-9]{2}:[0-9]{2}:[0-9]{2} ]]; then
            kill "$SPINNER_PID" 2>/dev/null
        fi
        if [[ "$line" == *"Verus Hashing"* ]]; then
            continue
        fi
        if [[ "$line" == *"😎Nice😎"* || "$line" =~ [0-9]{4}-[0-9]{2}-[0-9]{2} ]]; then
            LOG_LOCK=1
            clear
            tput cup $row 1
            echo -ne "\033[K$line"
            ((row++))
            if (( row > 20 )); then row=2; fi
            sleep 5
            LOG_LOCK=
            clear
        fi
    done
}

# Jalankan monitor dan spinner
monitor_output < "$PIPE" &
MONITOR_PID=$!

spinner $CCMINER_PID &
SPINNER_PID=$!

# Tunggu proses ccminer selesai
wait $CCMINER_PID

# Bersihkan semua proses & file
kill $MONITOR_PID 2>/dev/null
rm -f "$PIPE"
tput cnorm

# Jika keluar tidak normal, tampilkan pesan
if [[ $? -ne 0 ]]; then
    echo -e "\n\033[1;31m[!] ccminer keluar secara tidak normal.\033[0m"
fi
