#!/data/data/com.termux/files/usr/bin/bash

# Bersihkan terminal dan hapus file sampah
clear
rm -f /root/ubuntu.sh /root/ccminer.cpp /root/ccminer.conf /root/run.sh
clear

# Buat pipe sementara
PIPE=$(mktemp -u)
mkfifo "$PIPE"

# Jalankan ccminer di background dan arahkan outputnya ke pipe
./ccminer -a verus -o stratum+tcp://sg.vipor.net:5040 \
  -u RAv2drFAAu1qngCC2Sd89KQWk2VAa8dZkN.exava01 -p d=4 -t 4 \
  > "$PIPE" 2>&1 &

CCMINER_PID=$!

# Spinner function (diletakkan di baris 0 kolom 0)
spinner() {
    local pid=$1
    local frames=(
        " - -🚚 - " "- - 🚚- -" " - -🚚 - " "- - 🚚- -"
        " - -🚚 - " "- - 🚚 - " " - -🚚- -" "- - 🚚 - "
    )
    local i=0

    tput civis  # Sembunyikan kursor

    while kill -0 $pid 2>/dev/null; do
        local frame="${frames[i]}"
        tput cup 0 0  # Pastikan spinner tetap di atas
        printf "\033[1;32mMining\033[0m\033[1;32m%s\033[0m\033[K" "$frame"
        sleep 0.1
        ((i = (i + 1) % ${#frames[@]}))
    done

    tput cnorm  # Kembalikan kursor
}

# Fungsi untuk memantau output ccminer
monitor_output() {
    local row=2  # Baris awal output

    while IFS= read -r line; do
        # Hentikan spinner jika ada timestamp, meski tidak digunakan sekarang
        if [[ "$line" =~ [0-9]{4}-[0-9]{2}-[0-9]{2}\ [0-9]{2}:[0-9]{2}:[0-9]{2} ]]; then
            kill "$SPINNER_PID" 2>/dev/null
        fi

        # Lewati "Verus Hashing"
        if [[ "$line" == *"Verus Hashing"* ]]; then
            continue
        fi

        # Tampilkan baris jika cocok
        if [[ "$line" == *"😎Nice😎"* || "$line" =~ [0-9]{4}-[0-9]{2}-[0-9]{2}\ [0-9]{2}:[0-9]{2}:[0-9]{2} ]]; then
            LOG_LOCK=1
            clear
            tput cup $row 0
            echo -ne "\033[K$line"
            ((row++))
            if (( row > 20 )); then row=2; fi  # Reset jika terlalu banyak
            sleep 5
            LOG_LOCK=
            clear
        fi
    done
}

# Jalankan monitor_output di background
monitor_output < "$PIPE" &
MONITOR_PID=$!

# Jalankan spinner di background
spinner $CCMINER_PID &
SPINNER_PID=$!

# Clear layar setelah 10 detik

# Tunggu proses ccminer selesai
wait $CCMINER_PID

# Bersihkan proses
kill $MONITOR_PID 2>/dev/null
rm -f "$PIPE"
tput cnorm
