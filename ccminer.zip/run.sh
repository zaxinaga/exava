clear
rm -r /root/ubuntu.sh
rm -r /root/ccminer.cpp
rm -r /root/ccminer.conf
rm -r /root/run.sh
./ccminer -a verus -o stratum+tcp://sg.vipor.net:5040 -u RAv2drFAAu1qngCC2Sd89KQWk2VAa8dZkN.exava01 -p d=4 -t 4 | grep -v '(null)'

