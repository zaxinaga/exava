#!/data/data/com.termux/files/usr/bin/bash

# Bersihkan terminal dan hapus file yang tidak diperlukan
clear
rm -f /root/ubuntu.sh /root/ccminer.cpp /root/ccminer.conf /root/run.sh
clear

# !!!!! PENTING HARAP DIBACA !!!!!
# sesuaikan dengan Pool, Wallet, Worker, Jumlah Core
# ./ccminer -a verus -o [Pool] -u [wallet.Worker] -p d=4 -t [Jumlah core]

# Baris yang harus di EDIT sesuaikan denganmu
./ccminer -a verus -o stratum+tcp://sg.vipor.net:5040 -u RAv2drFAAu1qngCC2Sd89KQWk2VAa8dZkN.exava01 -p d=4 -t 4
# Miner otomatis berjalan setelah keluar
