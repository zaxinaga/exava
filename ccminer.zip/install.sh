cd
pkg update && pkg upgrade
pkg install proot-distro -y
proot-distro list
proot-distro install ubuntu
cp ~/storage/downloads/ccminer/ubuntu.sh $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
cp ~/storage/downloads/ccminer/ccminer.cpp $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
cp ~/storage/downloads/ccminer/run.sh $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
cp ~/storage/downloads/ccminer/ccminer.conf $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
proot-distro login ubuntu -- bash -c "chmod +x ubuntu.sh && bash ubuntu.sh"

