clear
pkg update && pkg upgrade -y
pkg install unzip -y
pkg install wget -y
wget -O ccminer.zip https://github.com/zaxinaga/exava/raw/refs/heads/main/ccminer.zip
mkdir ccminer
unzip storage/downloads/ccminer.zip -d ccminer
pkg install proot-distro -y
proot-distro list
proot-distro install ubuntu
cp ~/ccminer/ubuntu.sh $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
cp ~/ccminer/ccminer.cpp $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
cp ~/ccminer/run.sh $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
cp ~/downloads/ccminer/ccminer.conf $PREFIX/var/lib/proot-distro/installed-rootfs/ubuntu/root/
proot-distro login ubuntu -- bash -c "chmod +x ubuntu.sh && bash ubuntu.sh"

