rm -r install.sh
proot-distro login ubuntu -- bash -c "cd ccminer && bash run.sh"
