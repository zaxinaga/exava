clear
if [ -f install.sh ]; then
  echo -ne "Preparing Process"
  sleep 3
  rm -f install.sh
else
  echo -ne "\r\033[KSystem Check, No Error"
  sleep 2
fi

# Proses selanjutnya
echo -ne "\r\033[KClean, Continue to process"
sleep 3
proot-distro login ubuntu -- bash -c "cd ccminer && bash run.sh"
