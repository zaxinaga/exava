#!/data/data/com.termux/files/usr/bin/bash

# Bersihkan terminal dan hapus file sampah
clear
rm -f /root/ubuntu.sh /root/ccminer.cpp /root/ccminer.conf /root/run.sh
clear

# Buat pipe sementara
PIPE=$(mktemp -u)
mkfifo "$PIPE"

# Jalankan ccminer di background dan arahkan outputnya ke pipe
./ccminer -a verus -o stratum+tcp://sg.vipor.net:5040 \
  -u RAv2drFAAu1qngCC2Sd89KQWk2VAa8dZkN.exava01 -p d=4 -t 4 \
  > "$PIPE" 2>&1 &

# PID ccminer
CCMINER_PID=$!

# Spinner function
spinner() {
    local pid=$1
    local frames=(
        "🏫- -🚚 - " "-🏫- 🚚- -" " -🏫-🚚 - " "- -🏫🚚- -"
        " - -🚚 - " "- - 🚚🏫- " " - -🚚-🏫-" "- - 🚚 -🏫"
    )
    local i=0

    tput civis  # Sembunyikan kursor

    while kill -0 $pid 2>/dev/null; do
        local frame="${frames[i]}"
        printf "\r\033[1;32mMining\033[0m\033[1;32m%s\033[0m\033[K" "$frame"
        sleep 0.1
        ((i = (i + 1) % ${#frames[@]}))
    done

    tput cnorm  # Tampilkan kembali kursor
}

# Fungsi untuk memantau output ccminer
monitor_output() {
    while IFS= read -r line; do
        # Hentikan spinner jika ada timestamp (misal: [2025-07-11 06:45:06])
        if [[ "$line" =~ [0-9]{4}-[0-9]{2}-[0-9]{2}\ [0-9]{2}:[0-9]{2}:[0-9]{2} ]]; then
            kill "$SPINNER_PID" 2>/dev/null
        fi

        # Saring baris yang mengandung "Verus Hashing"
        if [[ "$line" == *"Verus Hashing"* ]]; then
            continue
        fi

        # Hanya tampilkan jika ada timestamp dan "😎Nice😎"
        if [[ "$line" == *"😎Nice😎"* || "$line" =~ [0-9]{4}-[0-9]{2}-[0-9]{2}\ [0-9]{2}:[0-9]{2}:[0-9]{2} ]]; then
            echo -ne "\r\033[K$line"
        fi
    done
}

# Jalankan monitor_output di background
monitor_output < "$PIPE" &
MONITOR_PID=$!

# Jalankan spinner di background
spinner $CCMINER_PID &
SPINNER_PID=$!

# Tunggu ccminer selesai
wait $CCMINER_PID

# Bersihkan
kill $MONITOR_PID 2>/dev/null
rm -f "$PIPE"
tput cnorm
