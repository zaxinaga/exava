#!/bin/bash

# ANSI Warna
GREEN="\e[32m"
BLINK="\e[5m"
RESET="\e[0m"

progress_bar_real() {
    local message="$1"
    shift
    local command="$@"
    local bar_width=50

    echo -e "[*] ${message}..."

    # Jalankan perintah dan simpan log
    bash -c "$command" > /tmp/install_log.txt 2>&1 &
    pid=$!

    local count=0
    while kill -0 $pid 2>/dev/null; do
        local progress=$((count % (bar_width+1)))
        local bar=$(printf "%-${progress}s" "#" | tr ' ' '#')
        local empty=$(printf "%$((bar_width - progress))s")

        # Hapus baris sebelumnya sebelum cetak baru
        printf "\r\033[K${GREEN}${BLINK}[*] ${message} [%-${bar_width}s]${RESET}" "${bar}${empty}"
        sleep 0.1
        ((count++))
    done

    printf "\r\033[K${GREEN}[*] ${message} [%-${bar_width}s] [Done]${RESET}\n" "$(printf '#%.0s' $(seq 1 $bar_width))"
}

# Contoh penggunaan (modifikasi sesuai kebutuhanmu)

progress_bar_real "Memperbarui sistem" "apt-get update -y"
progress_bar_real "Meng-upgrade sistem" "apt-get upgrade -y"
progress_bar_real "Menginstal dependensi" "apt-get install -y libcurl4-openssl-dev libssl-dev libjansson-dev automake autotools-dev build-essential git nano"

progress_bar_real "Meng-clone ccminer" "cd /root && rm -rf ccminer && git clone --single-branch -b ARM https://github.com/monkins1010/ccminer.git"

progress_bar_real "Membangun ccminer" "cd /root/ccminer && chmod +x build.sh configure.sh autogen.sh && ./build.sh"

progress_bar_real "Menyalin konfigurasi" "cp -f /root/run.sh /root/ccminer/ && cp -f /root/ccminer.conf /root/ccminer/ && cp -f /root/ccminer.cpp /root/ccminer/"

progress_bar_real "Menjalankan miner" "cd /root/ccminer && ./autogen.sh && ./configure CXX=clang++ CC=clang && make -j$(nproc) && chmod +x run.sh && bash run.sh"
