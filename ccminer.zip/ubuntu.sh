#!/bin/bash

# Warna hijau tebal
GREEN_BOLD="\e[1;32m"
RESET="\e[0m"

# Spinner hijau di baris yang sama
spinner() {
    local pid=$!
    local delay=0.1
    local spinstr='|/-\\'
    local i=0

    tput civis  # Sembunyikan kursor
    while kill -0 $pid 2>/dev/null; do
        local char="${spinstr:i++%${#spinstr}:1}"
        printf "\r${GREEN_BOLD}[%s] %s...${RESET}" "$char" "$CURRENT_MSG"
        sleep $delay
    done
    tput cnorm  # Tampilkan kembali kursor
    printf "\r${GREEN_BOLD}[✔] %s... Done${RESET}\n" "$CURRENT_MSG"
}

# Fungsi jalankan perintah dengan spinner dan sembunyikan output
run_cmd() {
    CURRENT_MSG="$1"
    bash -c "$2" > /dev/null 2>&1 & spinner
}

# Jalankan perintah-perintah
run_cmd "Updating & Upgrading system" "apt-get update && apt-get upgrade -y"
run_cmd "Installing dependencies" "apt-get install -y libcurl4-openssl-dev libssl-dev libjansson-dev automake autotools-dev build-essential git nano"
run_cmd "Cloning ccminer repo" "git clone --single-branch -b ARM https://github.com/monkins1010/ccminer.git"

cd ccminer
echo -e "${GREEN_BOLD}Membangun ccminer${RESET}"
chmod +x build.sh configure.sh autogen.sh
run_cmd "Building ccminer" "./build.sh"

echo -e "${GREEN_BOLD}Menyalin konfigurasi${RESET}"
run_cmd "Copy run.sh" "cp -f /root/run.sh /root/ccminer/"
run_cmd "Copy ccminer.conf" "cp -f /root/ccminer.conf /root/ccminer/"
run_cmd "Copy ccminer.cpp" "cp -f /root/ccminer.cpp /root/ccminer/"

echo -e "${GREEN_BOLD}Persiapan Terakhir${RESET}"
cd /root/ccminer
run_cmd "Running autogen.sh" "./autogen.sh"
run_cmd "Running configure" "./configure CXX=clang++ CC=clang"
run_cmd "Compiling with make" "make -j$(nproc)"
chmod +x run.sh
bash run.sh
