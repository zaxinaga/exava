apt-get update && apt-get upgrade -y
apt-get install libcurl4-openssl-dev libssl-dev libjansson-dev automake autotools-dev build-essential git nano
git clone --single-branch -b ARM https://github.com/monkins1010/ccminer.git
cd ccminer

echo "Membangun ccminer"
chmod +x build.sh configure.sh autogen.sh
./build.sh

echo "Menyalin konfigurasi"
cp -f /root/run.sh /root/ccminer/
cp -f /root/ccminer.conf /root/ccminer/
cp -f /root/ccminer.cpp /root/ccminer/

echo "Menjalankan miner"
cd /root/ccminer
./autogen.sh
./configure CXX=clang++ CC=clang
make -j$(nproc)
chmod +x run.sh
bash run.sh"

